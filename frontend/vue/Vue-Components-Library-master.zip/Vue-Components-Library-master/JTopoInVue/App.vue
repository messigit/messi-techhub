<template>
  <div id="app">
    <jtopo/>
  </div>
</template>

<script>
import jtopo from './components/jTopo'
export default {
  name: 'app',
  components:{jtopo}
}
</script>

